# Hero360Tour 1.2.3 — sensores móveis

Corrige o problema de leituras de orientação recebidas mas imóveis e a prioridade que impedia o acionamento do sensor alternativo. Modo por orientação para Android e iOS; fallback de taxa de rotação quando disponível (pode apresentar deriva). Requer HTTPS e permissão adequada. Teste em aparelhos reais permanece necessário.

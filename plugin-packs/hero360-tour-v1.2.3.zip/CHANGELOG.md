# 1.2.3

- Diferencia leituras de sensores de mudança de orientação efetiva.
- Evita que `deviceorientation` estático bloqueie fontes alternativas.
- Inicia `RelativeOrientationSensor`/`AbsoluteOrientationSensor` em caso de dados imóveis.
- Acrescenta fallback com `devicemotion.rotationRate` (com possível deriva), com solicitação de permissão na interação do usuário.
- Diagnóstico de dados ausentes ou estáticos; reinicialização segura de sensores por cena/orientação.
- Mantém renderização e hotspots do 1.2.2.

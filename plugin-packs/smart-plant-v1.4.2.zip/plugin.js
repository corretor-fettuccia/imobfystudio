(function () {
  'use strict';

  function esc(value) {
    return String(value == null ? '' : value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  var SAMPLE_ASSET = {
    p1:'assets/images/plant-1.png', p1full:'assets/images/plant-1-full.png',
    p2:'assets/images/plant-2.png', p3:'assets/images/plant-3.png', pos1:'assets/images/position-1.png'
  };
  function resolveSampleAsset(raw) {
    var key = String(raw || '').trim();
    var prefix = ['assets','images'].join('/') + '/';
    if (key === prefix + 'plant-1.png') return SAMPLE_ASSET.p1;
    if (key === prefix + 'plant-1-full.png') return SAMPLE_ASSET.p1full;
    if (key === prefix + 'plant-2.png') return SAMPLE_ASSET.p2;
    if (key === prefix + 'plant-3.png') return SAMPLE_ASSET.p3;
    if (key === prefix + 'smart-plant-position-1.png' || key === prefix + 'position-1.png') return SAMPLE_ASSET.pos1;
    return key;
  }
  function safeImage(value) {
    var raw = resolveSampleAsset(value);
    if (!raw) return '';
    if (/^data:image\//i.test(raw) || /^(?:https?:)?\/\//i.test(raw) || /^(?:\/|\.\/|\.\.\/)(?!\/)/.test(raw) || /^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.~%+@()-]+)+/.test(raw)) return raw;
    return '';
  }
  function normalizePlant(item, index) {
    item = item && typeof item === 'object' ? item : {};
    return {
      id:String(item.id || ('planta-' + (index + 1))),
      code:String(item.code || item.identifier || ''),
      title:String(item.title || ('Planta ' + (index + 1))),
      description:String(item.description || ''),
      area:String(item.area || ''),
      composition:String(item.composition || ''),
      bathrooms:String(item.bathrooms || ''),
      features:Array.isArray(item.features) ? item.features.join('|') : String(item.features || ''),
      image:String(item.image || ''),
      fullImage:String(item.fullImage || item.image || ''),
      positionImage:String(item.positionImage || ''),
      position:String(item.position || '')
    };
  }
  function readPlants(root) {
    try {
      var list = JSON.parse(root.dataset.plants || '[]');
      if (Array.isArray(list)) return list.map(normalizePlant);
    } catch (_) {}
    return [];
  }
  function badges(plant) {
    return [plant.area, plant.composition, plant.bathrooms].concat(String(plant.features || '').split('|').map(function (v) { return v.trim(); })).filter(Boolean);
  }
  function cardMarkup(plant, index, buttonText) {
    var image = safeImage(plant.image || plant.fullImage);
    return '<article class="smart-plant__card" data-smart-plant-card="' + esc(plant.id) + '">' +
      '<div class="smart-plant__card-media">' + (image ? '<img src="' + esc(image) + '" alt="' + esc(plant.title) + '"' + (index ? ' loading="lazy"' : '') + ' decoding="async">' : '') + '</div>' +
      '<div class="smart-plant__card-body"><h3>' + esc(plant.title) + '</h3>' +
      (plant.description ? '<p>' + esc(plant.description) + '</p>' : '') +
      '<div class="smart-plant__badges">' + badges(plant).map(function (item) { return '<span class="smart-plant__badge">' + esc(item) + '</span>'; }).join('') + '</div>' +
      '<button class="smart-plant__card-button" type="button" data-smart-plant-open="' + esc(plant.id) + '"><span>' + esc(buttonText || 'Ver planta completa') + '</span></button>' +
      '</div></article>';
  }
  function fillTemplate(template, root, plant) {
    return String(template || '')
      .replace(/\{empreendimento\}/gi, root.dataset.empreendimento || '')
      .replace(/\{planta\}/gi, plant.title || '')
      .replace(/\{metragem\}/gi, plant.area || '');
  }
  function init(wrapper) {
    if (wrapper.dataset.smartPlantReady === 'true') return;
    wrapper.dataset.smartPlantReady = 'true';
    var root = wrapper.querySelector('.smart-plant') || wrapper;
    var plants = readPlants(root);
    var grid = root.querySelector('[data-smart-plant-grid]');
    var modal = root.querySelector('[data-smart-plant-modal]');
    var active = null;
    var lockedScrollY = 0;
    var viewportHandler = null;
    var modalPortal = null;
    var lastTrigger = null;
    var closing = false;
    var magnifierCleanup = null;
    if (grid) grid.innerHTML = plants.map(function (plant, index) { return cardMarkup(plant, index, root.dataset.cardButtonText); }).join('');

    // O modal público é portado para o <body> para não herdar transform,
    // overflow, contain ou contexto de posicionamento da section Smart Plant.
    // Isso é essencial no Safari/iPhone, onde um ancestral transformado pode
    // transformar position:fixed em posicionamento relativo ao bloco ancestral.
    function ensureModalPortal() {
      if (!modal || modalPortal) return modalPortal;
      modalPortal = document.createElement('div');
      modalPortal.className = 'smart-plant-modal-portal';
      modalPortal.setAttribute('data-plugin', 'smart-plant');
      modalPortal.setAttribute('data-smart-plant-portal', '');
      document.body.appendChild(modalPortal);
      modalPortal.appendChild(modal);
      return modalPortal;
    }
    function syncPortalTheme() {
      if (!modalPortal) return;
      var cs = window.getComputedStyle(root);
      ['--sp-accent','--sp-modal','--sp-text','--sp-muted','--heading','--body-color','--heading-color'].forEach(function (name) {
        var value = cs.getPropertyValue(name);
        if (value) modalPortal.style.setProperty(name, value.trim());
      });
      modalPortal.style.fontFamily = cs.fontFamily || '';
    }
    function syncVisualViewportBox() {
      if (!modal) return;
      var vv = window.visualViewport;
      var left = vv ? vv.offsetLeft : 0;
      var top = vv ? vv.offsetTop : 0;
      var width = vv ? vv.width : window.innerWidth;
      var height = vv ? vv.height : window.innerHeight;
      modal.style.left = Math.round(left) + 'px';
      modal.style.top = Math.round(top) + 'px';
      modal.style.width = Math.round(width) + 'px';
      modal.style.height = Math.round(height) + 'px';
      modal.style.right = 'auto';
      modal.style.bottom = 'auto';
    }

    function unlockPage() {
      document.documentElement.classList.remove('smart-plant-modal-open');
      document.body.classList.remove('smart-plant-body-locked');
      document.body.style.top = '';
      document.body.style.width = '';
      if (window.visualViewport && viewportHandler) {
        window.visualViewport.removeEventListener('resize', viewportHandler);
        window.visualViewport.removeEventListener('scroll', viewportHandler);
      }
      window.removeEventListener('resize', viewportHandler);
      window.removeEventListener('orientationchange', viewportHandler);
      viewportHandler = null;
      // Safari iOS restaura o scroll com mais consistência após liberar o body.
      window.requestAnimationFrame(function () {
        window.scrollTo(0, lockedScrollY || 0);
      });
    }
    function fitModalToViewport() {
      if (!modal || !modal.classList.contains('is-open')) return;
      syncVisualViewportBox();
      var dialog = modal.querySelector('.smart-plant__dialog');
      if (!dialog) return;
      dialog.style.setProperty('--sp-modal-scale', '1');
      var vv = window.visualViewport;
      var vw = vv ? vv.width : window.innerWidth;
      var vh = vv ? vv.height : window.innerHeight;
      var padX = vw <= 640 ? 16 : 36;
      var padY = vw <= 640 ? 16 : 36;
      var naturalW = dialog.offsetWidth || 1;
      var naturalH = dialog.offsetHeight || 1;
      var scale = Math.min(1, (vw - padX) / naturalW, (vh - padY) / naturalH);
      if (!Number.isFinite(scale) || scale <= 0) scale = 1;
      // Sem barra interna: em telas realmente pequenas o conteúdo reduz como bloco.
      dialog.style.setProperty('--sp-modal-scale', String(Math.max(.32, scale)));
    }
    function lockPage() {
      lockedScrollY = window.scrollY || window.pageYOffset || 0;
      document.documentElement.classList.add('smart-plant-modal-open');
      document.body.classList.add('smart-plant-body-locked');
      document.body.style.top = (-lockedScrollY) + 'px';
      document.body.style.width = '100%';
      viewportHandler = function () {
        window.requestAnimationFrame(function () {
          syncVisualViewportBox();
          fitModalToViewport();
        });
      };
      if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', viewportHandler, { passive:true });
        window.visualViewport.addEventListener('scroll', viewportHandler, { passive:true });
      }
      window.addEventListener('resize', viewportHandler, { passive:true });
      window.addEventListener('orientationchange', viewportHandler, { passive:true });
    }
    function setupMagnifier(image) {
      if (magnifierCleanup) { try { magnifierCleanup(); } catch (_) {} magnifierCleanup = null; }
      if (!modal || !image) return;
      var stage = modal.querySelector('[data-smart-plant-magnifier-stage]');
      var lens = modal.querySelector('[data-smart-plant-magnifier]');
      var settingsToggle = modal.querySelector('[data-smart-plant-magnifier-settings-toggle]');
      var settingsPanel = modal.querySelector('[data-smart-plant-magnifier-settings]');
      var zoomButtons = Array.prototype.slice.call(modal.querySelectorAll('[data-smart-plant-zoom]'));
      if (!stage || !lens) return;

      function boolData(name, fallback) {
        var value = String(root.dataset[name] == null ? '' : root.dataset[name]).trim().toLowerCase();
        if (!value) return fallback;
        return !['false','0','no','off'].includes(value);
      }
      var touchToggle = boolData('magnifierTouchToggle', true);
      var clickPosition = boolData('magnifierClickPosition', true);
      var dragPosition = boolData('magnifierDragPosition', true);
      var followMouse = boolData('magnifierFollowMouse', false);
      var zoom = String(root.dataset.magnifierZoom || '3') === '2' ? 2 : 3;
      var dragging = false;
      var pointerId = null;
      var dragMoved = false;
      var downX = 0, downY = 0;
      var suppressLensClick = false;
      var touchStart = null;
      var lastTouchToggleAt = 0;

      lens.dataset.dragEnabled = dragPosition ? 'true' : 'false';

      function sourceUrl() { return safeImage(image.currentSrc || image.src || ''); }
      function updateZoomUi() {
        lens.setAttribute('aria-label', 'Lupa ' + zoom + ' vezes');
        zoomButtons.forEach(function (button) {
          button.classList.toggle('is-active', Number(button.dataset.smartPlantZoom) === zoom);
        });
      }
      function place(clientX, clientY) {
        var rect = stage.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        var x = Math.max(0, Math.min(rect.width, clientX - rect.left));
        var y = Math.max(0, Math.min(rect.height, clientY - rect.top));
        lens.style.left = x + 'px'; lens.style.top = y + 'px';
        lens.style.backgroundImage = 'url("' + sourceUrl().replace(/"/g,'\\"') + '")';
        lens.style.backgroundSize = (rect.width * zoom) + 'px ' + (rect.height * zoom) + 'px';
        lens.style.backgroundPosition = ((75 - x * zoom)) + 'px ' + ((75 - y * zoom)) + 'px';
      }
      function refreshAtCurrentPosition() {
        var rect = stage.getBoundingClientRect();
        var left = parseFloat(lens.style.left), top = parseFloat(lens.style.top);
        if (!Number.isFinite(left)) left = rect.width / 2;
        if (!Number.isFinite(top)) top = rect.height / 2;
        place(rect.left + left, rect.top + top);
      }
      function center() { var r = stage.getBoundingClientRect(); place(r.left + r.width/2, r.top + r.height/2); }
      function setVisible(visible) { lens.classList.toggle('is-hidden', !visible); }
      function toggleVisible() { setVisible(lens.classList.contains('is-hidden')); }
      function setSettingsOpen(open) {
        if (!settingsPanel) return;
        settingsPanel.classList.toggle('is-open', !!open);
        settingsPanel.setAttribute('aria-hidden', open ? 'false' : 'true');
        if (settingsToggle) settingsToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      function toggleSettings() { setSettingsOpen(!(settingsPanel && settingsPanel.classList.contains('is-open'))); }
      function chooseZoom(event) {
        var button = event.currentTarget;
        zoom = Number(button.dataset.smartPlantZoom) === 2 ? 2 : 3;
        updateZoomUi();
        refreshAtCurrentPosition();
        event.preventDefault(); event.stopPropagation();
      }
      function down(event) {
        if (!dragPosition) return;
        dragging = true; pointerId = event.pointerId; dragMoved = false; downX = event.clientX; downY = event.clientY;
        lens.classList.add('is-dragging');
        try { lens.setPointerCapture(pointerId); } catch (_) {}
        place(event.clientX,event.clientY); event.preventDefault(); event.stopPropagation();
      }
      function move(event) {
        if (!dragging || (pointerId != null && event.pointerId !== pointerId)) return;
        if (Math.abs(event.clientX-downX) > 3 || Math.abs(event.clientY-downY) > 3) dragMoved = true;
        place(event.clientX,event.clientY); event.preventDefault(); event.stopPropagation();
      }
      function up(event) {
        if (!dragging || (pointerId != null && event.pointerId !== pointerId)) return;
        suppressLensClick = true;
        if (!dragMoved) toggleSettings();
        dragging=false; lens.classList.remove('is-dragging');
        try { lens.releasePointerCapture(pointerId); } catch (_) {} pointerId=null;
        event.preventDefault(); event.stopPropagation();
        setTimeout(function () { suppressLensClick = false; }, 0);
      }
      function lensClick(event) {
        if (suppressLensClick) return;
        toggleSettings();
        event.preventDefault(); event.stopPropagation();
      }
      function stageClick(event) {
        if (!clickPosition || (Date.now() - lastTouchToggleAt) < 500) return;
        if (event.target.closest('[data-smart-plant-magnifier], [data-smart-plant-magnifier-settings], [data-smart-plant-magnifier-settings-toggle]')) return;
        if (event.pointerType === 'touch') return;
        setVisible(true); place(event.clientX,event.clientY);
      }
      function stagePointerMove(event) {
        if (!followMouse || dragging || event.pointerType !== 'mouse') return;
        if (event.target.closest('[data-smart-plant-magnifier-settings], [data-smart-plant-magnifier-settings-toggle]')) return;
        setVisible(true); place(event.clientX,event.clientY);
      }
      function stagePointerDown(event) {
        if (!touchToggle || event.pointerType !== 'touch') return;
        if (event.target.closest('[data-smart-plant-magnifier], [data-smart-plant-magnifier-settings], [data-smart-plant-magnifier-settings-toggle]')) return;
        touchStart = { id:event.pointerId, x:event.clientX, y:event.clientY };
      }
      function stagePointerUp(event) {
        if (!touchToggle || event.pointerType !== 'touch' || !touchStart || touchStart.id !== event.pointerId) return;
        if (event.target.closest('[data-smart-plant-magnifier], [data-smart-plant-magnifier-settings], [data-smart-plant-magnifier-settings-toggle]')) { touchStart=null; return; }
        var moved = Math.abs(event.clientX-touchStart.x) > 8 || Math.abs(event.clientY-touchStart.y) > 8;
        touchStart = null;
        if (moved) return;
        lastTouchToggleAt = Date.now();
        if (lens.classList.contains('is-hidden')) { setVisible(true); place(event.clientX,event.clientY); }
        else toggleVisible();
        event.preventDefault();
      }
      function toggleSettingsButton(event) { toggleSettings(); event.preventDefault(); event.stopPropagation(); }

      lens.addEventListener('pointerdown', down); lens.addEventListener('pointermove', move); lens.addEventListener('pointerup', up); lens.addEventListener('pointercancel', up); lens.addEventListener('click', lensClick);
      stage.addEventListener('click', stageClick); stage.addEventListener('pointermove', stagePointerMove); stage.addEventListener('pointerdown', stagePointerDown); stage.addEventListener('pointerup', stagePointerUp); stage.addEventListener('pointercancel', function(){ touchStart=null; });
      if (settingsToggle) settingsToggle.addEventListener('click', toggleSettingsButton);
      zoomButtons.forEach(function (button) { button.addEventListener('click', chooseZoom); });
      lens.classList.add('is-ready'); setVisible(true); updateZoomUi(); center(); setSettingsOpen(false);

      magnifierCleanup = function () {
        lens.removeEventListener('pointerdown',down); lens.removeEventListener('pointermove',move); lens.removeEventListener('pointerup',up); lens.removeEventListener('pointercancel',up); lens.removeEventListener('click',lensClick);
        stage.removeEventListener('click',stageClick); stage.removeEventListener('pointermove',stagePointerMove); stage.removeEventListener('pointerdown',stagePointerDown); stage.removeEventListener('pointerup',stagePointerUp);
        if (settingsToggle) settingsToggle.removeEventListener('click',toggleSettingsButton);
        zoomButtons.forEach(function (button) { button.removeEventListener('click',chooseZoom); });
        lens.classList.remove('is-ready','is-dragging','is-hidden'); setSettingsOpen(false);
      };
    }

    function closeModal() {
      if (!modal || closing || !modal.classList.contains('is-open')) return;
      closing = true;
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden','true');
      if (magnifierCleanup) { try { magnifierCleanup(); } catch (_) {} magnifierCleanup = null; }
      unlockPage();
      active = null;
      var restore = lastTrigger;
      lastTrigger = null;
      window.setTimeout(function () {
        closing = false;
        if (restore && restore.isConnected && restore.focus) {
          try { restore.focus({ preventScroll:true }); } catch (_) { restore.focus(); }
        }
      }, 30);
    }
    function openModal(id, trigger) {
      active = plants.find(function (item) { return String(item.id) === String(id); }) || null;
      if (!active || !modal) return;
      ensureModalPortal();
      syncPortalTheme();
      syncVisualViewportBox();
      lastTrigger = trigger || document.activeElement || null;
      closing = false;
      var image = modal.querySelector('[data-smart-plant-modal-image]');
      var title = modal.querySelector('[data-smart-plant-modal-title]');
      var badgeWrap = modal.querySelector('[data-smart-plant-modal-badges]');
      var positionImage = modal.querySelector('[data-smart-plant-position-image]');
      var position = modal.querySelector('[data-smart-plant-position]');
      var positionBlock = modal.querySelector('[data-smart-plant-position-block]');
      var action = modal.querySelector('[data-smart-plant-action]');
      var full = safeImage(active.fullImage || active.image);
      if (image) { image.src = full; image.alt = active.title || 'Planta'; }
      if (title) title.textContent = active.title;
      if (badgeWrap) badgeWrap.innerHTML = badges(active).map(function (item) { return '<span class="smart-plant__badge">' + esc(item) + '</span>'; }).join('');
      if (positionImage) {
        var posSrc = safeImage(active.positionImage);
        positionImage.src = posSrc;
        positionImage.style.display = posSrc ? 'block' : 'none';
      }
      if (position) position.textContent = active.position || '';
      if (positionBlock) positionBlock.style.display = (active.position || active.positionImage) ? '' : 'none';
      if (action) action.textContent = root.dataset.actionMode === 'form' ? (root.dataset.actionLabelForm || 'Gostei desta planta. Quero mais informações') : (root.dataset.actionLabelWhats || 'Gostei desta! Quero mais informações');
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden','false');
      lockPage();
      window.requestAnimationFrame(function () {
        fitModalToViewport();
        window.requestAnimationFrame(fitModalToViewport);
      });
      if (image) {
        image.onload = function () { fitModalToViewport(); setupMagnifier(image); };
        if (image.complete) setupMagnifier(image);
      }
      setTimeout(function () {
        fitModalToViewport();
        var closeButton = modal.querySelector('[data-smart-plant-close].smart-plant__close');
        if (closeButton && closeButton.focus) closeButton.focus({ preventScroll:true });
      }, 40);
    }
    function sendAction() {
      if (!active) return;
      var mode = root.dataset.actionMode === 'form' ? 'form' : 'whatsapp';
      if (mode === 'whatsapp') {
        var number = String(root.dataset.whatsNumber || '').replace(/\D+/g,'');
        var message = fillTemplate(root.dataset.whatsMessage, root, active);
        var url = 'https://wa.me/' + number + '?text=' + encodeURIComponent(message);
        window.open(url, '_blank', 'noopener');
        return;
      }
      var detail = {
        source:'smart-plant',
        empreendimento:root.dataset.empreendimento || '',
        plantId:active.id,
        plantCode:active.code || '',
        plantTitle:active.title,
        area:active.area,
        message:fillTemplate(root.dataset.formContextMessage, root, active),
        targetAnchor:String(root.dataset.formAnchor || '').replace(/^#/,'')
      };

      // Integração nativa com o Form Sender v4.
      // O Smart Plant grava o contexto diretamente no formulário que efetivamente
      // será submetido pelo Form Sender v4. Assim a planta escolhida chega no e-mail
      // mesmo quando o campo visual de mensagem estiver oculto.
      function locateFormSenderV4() {
        var scope = detail.targetAnchor ? document.getElementById(detail.targetAnchor) : null;
        var mount = null;
        if (scope) {
          if (scope.matches && scope.matches('.formsenderV4_mount')) mount = scope;
          if (!mount && scope.querySelector) mount = scope.querySelector('.formsenderV4_mount');
          if (!mount && scope.matches && scope.matches('[data-plugin="form-sender-v4"]')) mount = scope.querySelector('.formsenderV4_mount');
        }
        if (!mount) mount = document.querySelector('[data-plugin="form-sender-v4"] .formsenderV4_mount');
        if (!mount) mount = document.querySelector('.formsenderV4_mount');
        return mount;
      }

      function writeFormSenderV4Context(mount) {
        if (!mount) return false;
        var form = mount.querySelector('form');
        if (!form) return false;

        function setHidden(name, value) {
          var field = form.querySelector('[name="' + name + '"]');
          if (!field) {
            field = document.createElement('input');
            field.type = 'hidden';
            field.name = name;
            form.appendChild(field);
          }
          field.value = String(value || '');
        }

        setHidden('origem', 'Smart Plant');
        setHidden('smartPlantId', detail.plantId);
        setHidden('smartPlantCode', detail.plantCode);
        setHidden('smartPlant', detail.plantTitle);
        setHidden('smartPlantArea', detail.area);

        var msg = form.querySelector('[name="msg"]');
        if (!msg) {
          msg = document.createElement('input');
          msg.type = 'hidden';
          msg.name = 'msg';
          form.appendChild(msg);
        }

        var current = String(msg.value || '').trim();
        var previous = String(form.dataset.smartPlantMessage || '');
        if (previous && current.indexOf(previous) >= 0) current = current.replace(previous, '').trim();

        var lines = [
          detail.plantTitle ? 'Planta: ' + detail.plantTitle : '',
          detail.area ? 'Metragem: ' + detail.area : '',
          detail.plantCode ? 'Identificador: ' + detail.plantCode : ''
        ].filter(Boolean);
        if (detail.message) lines.push('', detail.message);
        var block = lines.join('\n').trim();

        form.dataset.smartPlantMessage = block;
        msg.value = [current, block].filter(Boolean).join('\n\n');
        mount.dataset.smartPlantSelected = detail.plantId || detail.plantTitle || 'true';
        return true;
      }

      var formSenderMount = locateFormSenderV4();
      var applied = writeFormSenderV4Context(formSenderMount);

      // Mantém o evento oficial para o adapter do Form Sender v4 e futuras integrações.
      // Só o dispara quando não foi possível aplicar diretamente, evitando duplicidade.
      if (!applied) {
        window.dispatchEvent(new CustomEvent('imobify:smart-plant-form', { detail:detail }));
      }

      closeModal();
      var target = formSenderMount || (detail.targetAnchor ? document.getElementById(detail.targetAnchor) : document.querySelector('[data-plugin="form-sender-v4"]'));
      if (target) {
        target.scrollIntoView({ behavior:'smooth', block:'center' });
        setTimeout(function () {
          var focusTarget = target.querySelector ? target.querySelector('input,textarea,button') : null;
          if (focusTarget && focusTarget.focus) focusTarget.focus({preventScroll:true});
        }, 500);
      } else {
        console.warn('[Smart Plant] Form Sender v4 não encontrado. Configure a âncora do Form Sender ou adicione uma seção form-sender-v4 à página.');
      }
    }
    root.addEventListener('click', function (event) {
      var open = event.target.closest('[data-smart-plant-open]');
      if (open) { openModal(open.dataset.smartPlantOpen, open); return; }
    });
    if (modal) {
      // Listener próprio porque o modal é movido para um portal fora da section.
      // Click é intencional: evita o duplo disparo touchend + click no Safari iOS.
      modal.addEventListener('click', function (event) {
        var closeControl = event.target.closest('[data-smart-plant-close]');
        if (closeControl) {
          event.preventDefault();
          event.stopPropagation();
          closeModal();
          return;
        }
        var actionControl = event.target.closest('[data-smart-plant-action]');
        if (actionControl) {
          event.preventDefault();
          sendAction();
        }
      });
    }
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && modal && modal.classList.contains('is-open')) closeModal(); });
  }
  function boot() { document.querySelectorAll('[data-plugin="smart-plant"]').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

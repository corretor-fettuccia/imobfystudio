# Hero360Tour 1.2.1 — Hotfix de inicialização

- Corrigida referência prematura ao registro de eventos (temporal dead zone) introduzida na 1.2.0.
- Inicialização completa do panorama no preview, no HTML exportado e no desktop mesmo sem sensores.
- Preservados o gyroscope, WebGL/Canvas2D e fallback da 1.1.4.
- Adicionado teste de inicialização para evitar o retorno da tela preta.

## Histórico

# Hero360Tour 1.2.0 — Immersive Motion

- Controles de navegação por sensores (somente em dispositivos touch com suporte).
- Permissão explícita nos navegadores que exigem, inclusive iOS Safari.
- Visão inicial preservada e calibração relativa ao entrar em cada cena.
- Conversão de orientação quaternion adequada à rotação de tela.
- Suavização, sensibilidade, recentralização e navegação por toque configuráveis.
- Sem captura do scroll vertical e sem interferência nos hotspots.
- Fallback seguro para navegação por toque quando o sensor não responder.
- Mantidas correções WebGL/Canvas 2D v1.1.4.

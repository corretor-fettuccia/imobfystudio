# Hero360Tour 1.2.1 — Verificações

- Verificação estática de JS/JSON, testes de catálogo e exportação.
- Testes em Chromium com emulação de orientação de dispositivo verificam ativação, calibração, persistência de cena, recentralização, permissão negada e toque.
- Teste físico com iPhone/iPad e Android reais é recomendado antes da publicação.

- Inicialização desktop e mobile em runtime após registro de eventos; `ims360Loaded=true`.

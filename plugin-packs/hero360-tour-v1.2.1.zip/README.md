# Hero360Tour 1.2.1 — Immersive Motion (hotfix de tela preta)

Mantém o renderizador WebGL + Canvas 2D, orientação inicial por cena, hotspots, navegação por toque e fallback de imagem estática.

## Navegação por movimento (mobile/tablet)

- No editor de componentes, configure **Modo imersivo — sensores**.
- `motionEnabled` habilita o botão **Explorar em 360°** (padrão: true).
- `motionActivation`: `button` (recomendado) ou `auto` apenas se o navegador não exigir autorização explícita.
- `motionSensitivity`: 10 a 100, padrão 50; `motionSmoothing`: 0 a 100, padrão 65.
- `motionRecenter` exibe o botão de recalibração; `motionTouchFallback` mantém arrasto horizontal mesmo com sensor ativo.
- Ao começar e ao mudar de ambiente, a orientação atual do dispositivo torna-se referência da `initialView` da cena.
- Não há leitura de sensor sem suporte e, nos navegadores que exigem permissão, ela só é solicitada por clique do visitante.
- Requer HTTPS (ou localhost), hardware compatível e permissões do navegador / iframe.
- Em caso de recusa ou ausência de dados, navegação por toque, teclado e hotspots continuam funcionando.
- Não usa serviços externos ou envia os valores dos sensores para servidores.

## Exportação

Propriedades declaradas no plugin.json, aplicadas no template.html (data-motion-*) e consumidas no plugin.js. Não requer bibliotecas externas nem migração dos JSONs antigos. O editor principal oferece as configurações; o editor interno de cenas mantém a captura de yaw/pitch/hfov.

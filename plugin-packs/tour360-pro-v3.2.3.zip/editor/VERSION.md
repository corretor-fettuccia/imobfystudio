# Tour 360 Editor — v3.2.2

## Correções de integração com ImobStudio 5.12.4
- O editor modal não espera mais Pannellum / JSZip externos para inicializar.
- Adicionar cena funciona e persiste mesmo enquanto o motor 360 ainda está carregando.
- No modo embutido, o autosave IndexedDB é desativado para nunca sobrescrever `section.props.tourConfig`.
- `ImobifyPluginEditor.load()` pode ser chamado antes do término da inicialização sem perder a configuração da section.
- Pannellum e JSZip passam a ser carregados sob demanda.
- Fluxo simulado: abrir modal → adicionar cena → salvar → reabrir configuração.

## Regra de não regressão
Mantidos os comportamentos consolidados de edição de cena/hotspot, perspectiva, navegação, branding e exportação.

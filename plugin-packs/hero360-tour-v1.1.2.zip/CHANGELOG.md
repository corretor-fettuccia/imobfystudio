## Hero360Tour 1.1.2 — Painel de navegação opcional

No inspetor do Imobify Studio, o campo **Habilitar painel de navegação** inicia desligado. Ao ativar, mostra os botões +, − e tela cheia na cena. A roda do mouse permanece dedicada à rolagem da LP. A edição de panoramas no Tour360 Studio continua com seus próprios controles.

## Atualização 1.1.1 — navegação e rolagem
Roda do mouse passa pela cena para rolar a página; arraste vertical da câmera limitado a 100 px; toque vertical preserva scroll nativo; zoom permanece disponível nos botões e teclado.

# Hero360Tour

## 1.1.0 · 2026-10-17
- Novo renderizador esférico WebGL independente com alternativa Canvas 2D.
- Cobertura de toda a seção e largura da viewport sem corte aos 1180px.
- Hotspots de informação reescrevem Eyebrow, Headline e descrição.
- Hotspots de navegação mudam diretamente de cena.
- Panoramas com resolução superior à capacidade GPU são reduzidos para textura 2:1 segura.

## Hero360Tour 1.1.2 — Painel de navegação opcional

No inspetor do Imobify Studio, o campo **Habilitar painel de navegação** inicia desligado. Ao ativar, mostra os botões +, − e tela cheia na cena. A roda do mouse permanece dedicada à rolagem da LP. A edição de panoramas no Tour360 Studio continua com seus próprios controles.

## Atualização 1.1.1 — navegação e rolagem
Roda do mouse passa pela cena para rolar a página; arraste vertical da câmera limitado a 100 px; toque vertical preserva scroll nativo; zoom permanece disponível nos botões e teclado.

# Hero360Tour v1.1.0 — projeção esférica independente

- O viewer público usa WebGL nativo equiretangular, sem dependência de Pannellum ou CDN.
- Alternativa Canvas 2D interativa nos dispositivos sem WebGL, com resolução reduzida.
- Imagens equiretangulares 2:1 (ex.: 6912 × 3456) são reprojetadas na seção toda, independentemente da largura do contêiner.
- Hotspots do editor preservados: SVG, rotação, escala, perspectiva, yaw e pitch.
- Informação atualiza texto do Hero e desloca a câmera; navegação entra diretamente na cena escolhida.
- Inatividade de 10 segundos inicia movimento leve do observador.
- Tour360 original e Parallax360Tour não foram alterados.
- O editor de panoramas pode continuar a usar Pannellum; a landing page exportada não depende dele.

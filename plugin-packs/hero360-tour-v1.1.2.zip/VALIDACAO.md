## Hero360Tour 1.1.2 — Painel de navegação opcional

No inspetor do Imobify Studio, o campo **Habilitar painel de navegação** inicia desligado. Ao ativar, mostra os botões +, − e tela cheia na cena. A roda do mouse permanece dedicada à rolagem da LP. A edição de panoramas no Tour360 Studio continua com seus próprios controles.

# Hero360Tour v1.0.5 - validação

- Regras problemáticas removidas; sem override de elementos internos `pnlm-*`.
- Foto panorâmica permanece em tela cheia enquanto o motor carrega; desaparece após evento de carregamento real.
- O tamanho do WebGL é atualizado pela API pública `viewer.resize()`.
- Teste com motor real Pannellum em navegador com conexão continua recomendado, especialmente usando o panorama original do cliente.

# Hero360Tour 1.2.2 — Movimento em Android/iOS

O botão “Explorar em 360°” inicia a navegação física em navegadores compatíveis, com permissão quando exigida. Funciona via eventos de orientação e inclui fallback Generic Sensor para Chromium/Android. O status do sensor aparece junto aos controles, sem esconder falhas.

**Requisitos:** HTTPS no site; sensores físicos; navegador com acesso a orientação; permitir acelerômetro e giroscópio em frames incorporados. Em preview com `sandbox`, prefira testar o HTML exportado em uma página HTTPS própria.

A navegação por arrasto e os hotspots continuam disponíveis quando a autorização não é concedida.

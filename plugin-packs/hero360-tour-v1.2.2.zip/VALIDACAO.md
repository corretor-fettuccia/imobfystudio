# Validação Hero360Tour 1.2.2

- Teste funcional Chromium com DeviceOrientation simulado no Android e no iOS: amostras recebidas, panorama movido e hotspot navegável.
- Teste funcional Chromium com Generic Sensor simulado: leitura e fallback conectados.
- Teste de bloqueio por Permissions Policy: estado visível e controle não ativado.
- Testes de regressão Hero360Tour, sintaxe, exportação e Plugin Play executados.
- **Não testado:** sensores físicos em celulares/tablets reais nem políticas de hospedagens de terceiros.

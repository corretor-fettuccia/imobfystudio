# Hero360Tour 1.2.2 — sensores Android/iOS

- Corrigida a dependência de um único evento do navegador: leitura de `deviceorientation` e `deviceorientationabsolute`.
- Android/Chromium: fallback para `RelativeOrientationSensor` / `AbsoluteOrientationSensor` quando os eventos não respondem.
- iOS/iPadOS: mantém autorização explícita no gesto do usuário.
- Diagnóstico visível de HTTPS, bloqueio de política, permissão negada, ausência de dados e sensor indisponível.
- Permissões delegadas aos frames do preview quando permitido pelo navegador; sandbox preservado.
- Calibração por cena, hotspots, toque e fallback WebGL/Canvas 2D preservados.
- Modo imersivo nunca exige sensores para a visita funcionar: navegação por toque permanece.

Limite: não é possível garantir acesso de sensores em iframes restritos e sem HTTPS. Teste real em aparelhos permanece necessário.

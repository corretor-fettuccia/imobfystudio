# Hero360Tour 1.2.5 — Calibração inteligente

O tour móvel apresenta apenas um botão: **Explorar em 360°** antes da ativação e **Desativar movimento** enquanto ativo. Sem painel de debug, sem contadores, sem botão extra de recentralização.

A câmera 360 usa a posição inicial da cena como referência, calibra as primeiras leituras automaticamente, recalibra ao mudar de cena/orientação da tela, filtra ruído e rejeita saltos isolados. Usa `deviceorientation` com Generic Sensor / `devicemotion` quando disponíveis. Navegação por toque preservada. Requer HTTPS/permissão conforme navegador.

A correção deve ser testada em aparelhos reais Android e iOS; testes automatizados não garantem sensores físicos nem políticas do navegador.

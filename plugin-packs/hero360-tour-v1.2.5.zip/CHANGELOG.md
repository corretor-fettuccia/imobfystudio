# Hero360Tour 1.2.5 — interface limpa e orientação calibrada

- Remove painel de diagnóstico e botão `?` da interface pública.
- Apenas um botão de ativar/desativar movimento.
- Calibração curta da orientação inicial, automática em trocas de cena/fonte e mudanças retrato/paisagem.
- Suavização adaptativa com menor atraso, zona morta anti-jitter e proteção contra viradas bruscas de um único frame.
- Congela direção horizontal em ângulos quase verticais para evitar reversões de 180 graus.
- Preserva hotspots, scroll, seleção de cena e fallback de renderização.

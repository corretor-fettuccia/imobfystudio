/** Hero360Tour v1.1.3 - panorama full viewport, WebGL native, no third-party runtime. */
(function () {
 'use strict';
 const ID = 'hero360-tour';
 const instances = new WeakMap();
 const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
 const rad = v => v * Math.PI / 180;
 const deg = v => v * 180 / Math.PI;
 const wrap = v => ((v + 180) % 360 + 360) % 360 - 180;
 const safeUrl = v => {try { const url = new URL(v,document.baseURI);return ['https:','http:','mailto:','tel:'].includes(url.protocol) ? url.href : ''; } catch { return ''; }};
 function parse(el) { try { return JSON.parse(el.querySelector('.ims360-config')?.value || '{}') || {}; } catch {return {};}}
 function glyph(type) {
   if(type==='info')return '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="27" class="hs-disc"/><circle cx="32" cy="21" r="3.5" class="hs-fill"/><path d="M32 29v18" class="hs-stroke"/></svg>';
   if(type==='external')return '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="27" class="hs-disc"/><path d="M25 39 42 22M31 22h11v11" class="hs-stroke"/></svg>';
   return '<svg viewBox="0 0 64 64" aria-hidden="true"><ellipse cx="32" cy="50" rx="18" ry="6" class="hs-shadow"/><path d="M32 8 49 33H39v18H25V33H15Z" class="hs-arrow"/><path d="M32 11 45 31H36v17h-8V31h-9Z" class="hs-highlight"/></svg>';
 }
 const VS = `attribute vec2 a;varying vec2 uv;void main(){uv=a;gl_Position=vec4(a,0.0,1.0);}`;
 const FS = `precision highp float;
 varying vec2 uv;uniform sampler2D pano;uniform vec2 resolution;uniform float yaw;uniform float pitch;uniform float tanHalf;
 const float PI=3.141592653589793;
 void main(){
  float aspect=resolution.x/resolution.y;
  vec3 d=normalize(vec3(uv.x*tanHalf,uv.y*tanHalf/aspect,1.0));
  float cp=cos(pitch),sp=sin(pitch),cy=cos(yaw),sy=sin(yaw);
  vec3 p=vec3(d.x,cp*d.y+sp*d.z,cp*d.z-sp*d.y);
  vec3 world=vec3(cy*p.x+sy*p.z,p.y,cy*p.z-sy*p.x);
  float longitude=atan(world.x,world.z);
  float latitude=asin(clamp(world.y,-1.0,1.0));
  vec2 tex=vec2(fract(0.5+longitude/(2.0*PI)),clamp(0.5+latitude/PI,0.0,1.0));
  gl_FragColor=texture2D(pano,tex);
 }`;
 function createGL(canvas) {
   const gl = canvas.getContext('webgl',{alpha:false,antialias:false,preserveDrawingBuffer:false, powerPreference:'high-performance'}) || canvas.getContext('experimental-webgl');
   if(!gl)return null;
   function compile(type,src){const shader=gl.createShader(type);gl.shaderSource(shader,src);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('Shader 360: '+gl.getShaderInfoLog(shader));return shader;}
   const program=gl.createProgram();gl.attachShader(program,compile(gl.VERTEX_SHADER,VS));gl.attachShader(program,compile(gl.FRAGMENT_SHADER,FS));gl.linkProgram(program);
   if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('WebGL 360: '+gl.getProgramInfoLog(program));
   gl.useProgram(program);
   const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
   const a=gl.getAttribLocation(program,'a');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);
   const uniforms={resolution:gl.getUniformLocation(program,'resolution'),yaw:gl.getUniformLocation(program,'yaw'),pitch:gl.getUniformLocation(program,'pitch'),tanHalf:gl.getUniformLocation(program,'tanHalf'),pano:gl.getUniformLocation(program,'pano')};
   const tex=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
   gl.uniform1i(uniforms.pano,0);
   return {gl,program,buffer,tex,uniforms,textureReady:false,maxTexture:gl.getParameter(gl.MAX_TEXTURE_SIZE),destroy(){gl.deleteTexture(tex);gl.deleteBuffer(buffer);gl.deleteProgram(program)}};
 }

 function createCPU(canvas){
   const ctx=canvas.getContext('2d',{alpha:false,willReadFrequently:true});if(!ctx)return null;
   return {gl:null,ctx,textureReady:false,src:null,sw:0,sh:0,maxTexture:2048,destroy(){this.src=null},lastDraw:0};
 }
 function drawCPU(canvas,engine,yaw,pitch,hfov){
   if(!engine.src)return;
   const ctx=engine.ctx,W=canvas.width,H=canvas.height,src=engine.src,sw=engine.sw,sh=engine.sh;
   const output=ctx.createImageData(W,H),pixels=output.data,aspect=W/H,tan=Math.tan(hfov*Math.PI/360);
   const ya=yaw*Math.PI/180,pa=pitch*Math.PI/180,cp=Math.cos(pa),sp=Math.sin(pa),cy=Math.cos(ya),sy=Math.sin(ya);
   let j=0;
   for(let row=0;row<H;row++){
     const v=(1-2*(row+.5)/H)*tan/aspect;
     for(let col=0;col<W;col++){
       const u=(2*(col+.5)/W-1)*tan;
       const inv=1/Math.sqrt(1+u*u+v*v),dx=u*inv,dy=v*inv,dz=inv;
       const yy=cp*dy+sp*dz,zz=cp*dz-sp*dy;
       const wx=cy*dx+sy*zz,wz=cy*zz-sy*dx;
       const lon=Math.atan2(wx,wz),lat=Math.asin(Math.max(-1,Math.min(1,yy)));
       const sx=((Math.floor((.5+lon/(2*Math.PI))*sw)%sw)+sw)%sw;
       const syy=Math.max(0,Math.min(sh-1,Math.floor((.5-lat/Math.PI)*sh)));
       const k=(syy*sw+sx)*4;
       pixels[j++]=src[k];pixels[j++]=src[k+1];pixels[j++]=src[k+2];pixels[j++]=255;
     }
   }
   ctx.putImageData(output,0,0);
 }
 function initialize(root) {
  if(instances.has(root))return;
  const cfg=parse(root),scenes=cfg.scenes||{};
  const order=(Array.isArray(cfg.sceneOrder)?cfg.sceneOrder:Object.keys(scenes)).filter(id=>scenes[id]?.panorama);
  const stage=root.querySelector('.ims360-frame'),view=root.querySelector('.ims360-viewer'),poster=root.querySelector('.ims360-poster'),err=root.querySelector('.ims360-error'),label=root.querySelector('.ims360-scene-name');
  if(!stage||!view)return;
  const hero={eyebrow:root.querySelector('.ims360-eyebrow'),headline:root.querySelector('.ims360-headline'),body:root.querySelector('.ims360-subheadline'),cta:root.querySelector('[data-hero-cta]')};
  const defaults={eyebrow:hero.eyebrow?.textContent||'',headline:hero.headline?.textContent||'',body:hero.body?.textContent||''};
  root.style.setProperty('--ims360-opacity',String(clamp(parseFloat(root.style.getPropertyValue('--ims360-overlay')),0,75)/100));
  if(hero.cta){const href=safeUrl(hero.cta.getAttribute('href'));hero.cta.hidden=!href;if(href)hero.cta.href=href;}
  if(!order.length){const empty=root.querySelector('.ims360-empty');if(empty)empty.hidden=false;root.dataset.ims360Loaded='empty';return;}
  let canvas=document.createElement('canvas');canvas.className='ims360-gl';canvas.setAttribute('aria-label','Panorama 360 interativo');
  view.replaceChildren(canvas);
  const hotspotLayer=document.createElement('div');hotspotLayer.className='ims360-hotspot-layer';view.appendChild(hotspotLayer);
  let engine;
  try{engine=createGL(canvas)}catch(e){console.warn('[Hero360Tour] WebGL indisponível:',e)}
  if(!engine){
    // Um contexto WebGL parcialmente inicializado não permite reabrir o MESMO canvas em 2D.
    // Substituir o elemento garante o fallback quando a compilação do shader falhar no preview.
    const fallback=document.createElement('canvas');fallback.className=canvas.className;
    fallback.setAttribute('aria-label',canvas.getAttribute('aria-label'));
    canvas.replaceWith(fallback);canvas=fallback;
    engine=createCPU(canvas);
    root.dataset.ims360Renderer='canvas2d';
  }else root.dataset.ims360Renderer='webgl';
  if(!engine){if(err){err.textContent='Canvas indisponível; mostrando imagem estática.';err.hidden=false;}if(poster){poster.hidden=false;poster.src=scenes[order[0]].panorama;}root.dataset.ims360Loaded='error';return;}
  let gl=engine.gl;
  let disposed=false,sceneId=cfg.settings?.firstSceneId&&scenes[cfg.settings.firstSceneId]?.panorama?cfg.settings.firstSceneId:order[0];
  let yaw=0,pitch=0,hfov=clamp(root.dataset.heroHfov||118,60,140);
  let frame=0,resizeObserver=null,visible=true,dirty=true,transition=null,sequence=0,interactionAt=performance.now(),idleAnchor=null,pointer=null,hotspots=[];
  const idleMs=clamp(root.dataset.idle||10,5,60)*1000, swayYaw=clamp(root.dataset.swayYaw||7,0,16),swayPitch=clamp(root.dataset.swayPitch||.8,0,3),cycleMs=clamp(root.dataset.swayCycle||19,8,35)*1000;
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)');
  const disposers=[];
  function on(t,e,f,opt){t.addEventListener(e,f,opt);disposers.push(()=>t.removeEventListener(e,f,opt));}
  function resetHero(){if(hero.eyebrow)hero.eyebrow.textContent=defaults.eyebrow;if(hero.headline)hero.headline.textContent=defaults.headline;if(hero.body)hero.body.textContent=defaults.body;stage.classList.remove('ims360-spot-selected')}
  function setHero(h,s){if(hero.eyebrow)hero.eyebrow.textContent=h.bannerEyebrow||h.heroEyebrow||h.text||s.title||'';if(hero.headline)hero.headline.textContent=h.bannerHeadline||h.heroHeadline||h.text||s.title||'';if(hero.body)hero.body.textContent=h.bannerBody||h.heroSubheadline||h.info||'';stage.classList.add('ims360-spot-selected')}
  function stopIdle(){interactionAt=performance.now();idleAnchor=null}
  function animateTo(y,p,h=null){const start=performance.now();const orig={yaw,pitch,hfov};transition={start,from:orig,to:{yaw:yaw+wrap(y-yaw),pitch:clamp(p,-80,80),hfov:h||hfov},duration:reduced?.matches?0:750};stopIdle();dirty=true}
  function uploadImage(img){
    const w=img.naturalWidth,h=img.naturalHeight;
    if(!w||!h)throw Error('Imagem sem dimensões');
    const max=Math.min(engine.maxTexture,gl?4096:2048);const outWidth=Math.max(256,Math.min(w,max));const outHeight=Math.max(128,Math.round(outWidth/2));
    const off=document.createElement('canvas');off.width=outWidth;off.height=outHeight;
    const ctx=off.getContext('2d',{alpha:false});if(!ctx)throw Error('Canvas de panorama indisponível');
    ctx.drawImage(img,0,0,outWidth,outHeight);
    if(gl){
      try {
        gl.bindTexture(gl.TEXTURE_2D,engine.tex);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,off);
        const glError=gl.getError();
        if(glError!==gl.NO_ERROR)throw new Error('Falha na textura WebGL: '+glError);
      } catch(error) {
        console.warn('[Hero360Tour] Ativando renderização 2D:',error);
        try{engine.destroy()}catch(_){}
        const fallback=document.createElement('canvas');fallback.className=canvas.className;
        fallback.setAttribute('aria-label',canvas.getAttribute('aria-label'));
        canvas.replaceWith(fallback);canvas=fallback;
        engine=createCPU(canvas);gl=null;
        if(!engine)throw error;
        root.dataset.ims360Renderer='canvas2d';
        bindCanvasEvents();
      }
    }
    if(!gl){
      const raw=ctx.getImageData(0,0,outWidth,outHeight);
      engine.src=raw.data;engine.sw=outWidth;engine.sh=outHeight;
    }
    engine.textureReady=true;dirty=true;
    root.dataset.ims360Loaded='true';
    if(poster){poster.classList.add('ims360-ready');poster.hidden=true;}
    if(err)err.hidden=true;
  }
  function loadScene(id,targetView){
    if(!scenes[id]?.panorama)return;
    const serial=++sequence;
    const s=scenes[id];sceneId=id;label.textContent=s.title||id;
    resetHero();stopIdle();transition=null;
    const v=targetView||s.initialView||{};yaw=Number.isFinite(Number(v.yaw))?wrap(Number(v.yaw)):0;pitch=clamp(v.pitch??0,-80,80);hfov=clamp(v.hfov??root.dataset.heroHfov??118,50,140);
    hotspots=[];hotspotLayer.replaceChildren();
    for(const spot of s.hotspots||[]){
      const el=document.createElement('div');el.className='ims360-hotspot-shell';el.dataset.hotspotId=spot.id||'';el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-label',spot.text||'Ponto de interesse');
      const scale=document.createElement('div');scale.className='hotspot-scale';const perspective=document.createElement('div');perspective.className='hotspot-perspective';const pulse=document.createElement('span');pulse.className='hotspot-pulse';perspective.appendChild(pulse);
      const rotate=document.createElement('div');rotate.className='hotspot-rotate';rotate.style.transform=`rotate(${Number(spot.rotation)||0}deg)`;
      const icon=document.createElement('div');icon.className='hotspot-icon';icon.innerHTML=glyph(spot.type);rotate.appendChild(icon);perspective.appendChild(rotate);scale.appendChild(perspective);el.appendChild(scale);
      const strength=clamp(spot.perspectiveStrength??1,0,2),floor=clamp(-Number(spot.pitch||0)/48,0,1),tilt=spot.perspective===false?0:(6+floor*70)*strength,depth=spot.perspective===false?1:1-floor*.18*strength,vertical=spot.perspective===false?1:1-floor*.22*strength,ss=clamp(spot.scale??1,.5,2)*depth;
      perspective.style.transform=`perspective(220px) rotateX(${tilt}deg) scale(${ss},${ss*vertical})`;
      if(spot.text){const name=document.createElement('span');name.className='ims360-hotspot-tooltip';name.textContent=spot.text;el.append(name)}
      function activate(e){e.preventDefault();e.stopPropagation();stopIdle();if(spot.type==='navigation'&&scenes[spot.targetSceneId]?.panorama){loadScene(spot.targetSceneId,spot.targetView);return;}if(spot.type==='info'){animateTo(Number(spot.yaw)||0,Number(spot.pitch)||0);setHero(spot,s);return;}if(spot.type==='external'){const url=safeUrl(spot.url);if(url)window.open(url,'_blank','noopener,noreferrer');}}
      el.addEventListener('click',activate);el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')activate(e)});
      hotspotLayer.appendChild(el);hotspots.push({spot,el});
    }
    root.dataset.ims360Loaded='false';
    if(poster){poster.src=s.panorama;poster.hidden=false;poster.classList.remove('ims360-ready')}
    const image=new Image();image.decoding='async';
    if(/^https?:\/\//i.test(String(s.panorama)))image.crossOrigin='anonymous';
    image.onload=()=>{if(disposed||serial!==sequence)return;try{uploadImage(image);}catch(error){showError(error)}};
    image.onerror=()=>{if(!disposed&&serial===sequence)showError(new Error('Falha ao carregar panorama: '+s.panorama))};
    image.src=s.panorama;
    dirty=true;
  }
  function showError(error){console.warn('[Hero360Tour]',error);if(err){err.textContent='Falha ao carregar a imagem 360. A imagem estática permanece disponível.';err.hidden=false}}
  function resize(){const w=Math.max(1,Math.floor(view.clientWidth)),h=Math.max(1,Math.floor(view.clientHeight));const dpr=Math.min(window.devicePixelRatio||1,1.5);const scale=gl?dpr:Math.min(1,560/w);const tw=Math.max(1,Math.round(w*scale)),th=Math.max(1,Math.round(h*scale));if(canvas.width!==tw||canvas.height!==th){canvas.width=tw;canvas.height=th;canvas.style.width=w+'px';canvas.style.height=h+'px';if(gl)gl.viewport(0,0,tw,th);dirty=true;} }
  function projectSpots(){
    const w=view.clientWidth,h=view.clientHeight;if(!w||!h)return;
    const aspect=w/h,tanHalf=Math.tan(rad(hfov)/2),cy=Math.cos(rad(yaw)),sy=Math.sin(rad(yaw)),cp=Math.cos(rad(pitch)),sp=Math.sin(rad(pitch));
    for(const {spot,el} of hotspots){const a=rad(Number(spot.yaw)||0),b=rad(Number(spot.pitch)||0),worldX=Math.sin(a)*Math.cos(b),worldY=Math.sin(b),worldZ=Math.cos(a)*Math.cos(b);
      const x=cy*worldX-sy*worldZ,z0=sy*worldX+cy*worldZ,y=cp*worldY-sp*z0,z=sp*worldY+cp*z0;
      if(z<=.01){el.hidden=true;continue;}
      const u=(x/z)/tanHalf,v=(y/z)*aspect/tanHalf;
      el.hidden=Math.abs(u)>1.09||Math.abs(v)>1.09;
      if(!el.hidden){el.style.left=((u+1)*w/2)+'px';el.style.top=((1-v)*h/2)+'px';}
    }
  }
  function render(){
    if(!engine.textureReady)return;
    resize();
    if(gl){gl.useProgram(engine.program);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,engine.tex);
    gl.uniform2f(engine.uniforms.resolution,canvas.width,canvas.height);
    gl.uniform1f(engine.uniforms.yaw,rad(yaw));gl.uniform1f(engine.uniforms.pitch,rad(pitch));gl.uniform1f(engine.uniforms.tanHalf,Math.tan(rad(hfov)/2));
    gl.drawArrays(gl.TRIANGLE_STRIP,0,4);}
    else {drawCPU(canvas,engine,yaw,pitch,hfov);engine.lastDraw=performance.now();}
    projectSpots();dirty=false;
  }
  function tick(t){if(disposed)return;
    if(transition){const e=transition.duration?clamp((t-transition.start)/transition.duration,0,1):1,sm=e*e*(3-2*e);yaw=wrap(transition.from.yaw+(transition.to.yaw-transition.from.yaw)*sm);pitch=transition.from.pitch+(transition.to.pitch-transition.from.pitch)*sm;hfov=transition.from.hfov+(transition.to.hfov-transition.from.hfov)*sm;dirty=true;if(e>=1)transition=null;}
    else if(!reduced?.matches&&visible&&t-interactionAt>=idleMs){if(!idleAnchor)idleAnchor={t,yaw,pitch};const dt=(t-idleAnchor.t)/cycleMs*Math.PI*2;yaw=wrap(idleAnchor.yaw+Math.sin(dt)*swayYaw);pitch=clamp(idleAnchor.pitch+Math.sin(dt*.63)*swayPitch,-80,80);dirty=true;}
    if(visible&&dirty&&(gl||t-engine.lastDraw>115))render();frame=requestAnimationFrame(tick);
  }
  // Gesture arbitration: page scrolling always wins over vertical touch gestures.
  // The camera uses at most 100px of vertical mouse drag; horizontal rotation remains unrestricted.
  const VERTICAL_DRAG_LIMIT=100;
  function pdown(e){
    if(e.button!==0 || (e.pointerType==='touch' && e.isPrimary===false))return;
    const touch=e.pointerType==='touch';
    pointer={id:e.pointerId,x:e.clientX,y:e.clientY,yaw,pitch,touch,axis:touch?'pending':'drag'};
    transition=null;stopIdle();
    // Do not capture touch until a horizontal gesture is identified, so the browser can pan vertically.
    if(!touch)try{canvas.setPointerCapture?.(e.pointerId)}catch(_){}
  }
  function pmove(e){
    if(!pointer||pointer.id!==e.pointerId)return;
    const deltaX=e.clientX-pointer.x,deltaY=e.clientY-pointer.y;
    if(pointer.touch && pointer.axis==='pending'){
      if(Math.max(Math.abs(deltaX),Math.abs(deltaY))<8)return;
      if(Math.abs(deltaY)>Math.abs(deltaX)){
        // touch-action:pan-y gives the vertical gesture directly to native document scrolling.
        pointer=null;return;
      }
      pointer.axis='horizontal';
      try{canvas.setPointerCapture?.(e.pointerId)}catch(_){}
    }
    const gain=hfov/Math.max(200,view.clientWidth);
    yaw=wrap(pointer.yaw-deltaX*gain);
    // Never consume more than 100px on the vertical axis while dragging the panorama.
    pitch=clamp(pointer.pitch+clamp(deltaY,-VERTICAL_DRAG_LIMIT,VERTICAL_DRAG_LIMIT)*gain,-80,80);
    dirty=true;stopIdle();
  }
  function pup(e){
    if(pointer?.id!==e.pointerId)return;
    pointer=null;stopIdle();
    try{if(canvas.hasPointerCapture?.(e.pointerId))canvas.releasePointerCapture(e.pointerId)}catch(_){}
  }
  function zoom(delta){hfov=clamp(hfov+delta,50,140);dirty=true;stopIdle();}
  function bindCanvasEvents(){on(canvas,'pointerdown',pdown);on(canvas,'pointermove',pmove);on(canvas,'pointerup',pup);on(canvas,'pointercancel',pup);on(canvas,'keydown',keyControl);canvas.tabIndex=0;}
  // No wheel handler: wheel / trackpad scroll the landing page, not the panorama.
  const navigationPanelEnabled=root.dataset.navigationPanel==='true';
  function keyControl(e){let handled=true;if(e.key==='ArrowLeft')yaw=wrap(yaw-5);else if(e.key==='ArrowRight')yaw=wrap(yaw+5);else if(e.key==='ArrowUp')pitch=clamp(pitch+5,-80,80);else if(e.key==='ArrowDown')pitch=clamp(pitch-5,-80,80);else if(navigationPanelEnabled&&(e.key==='+'||e.key==='='))zoom(-5);else if(navigationPanelEnabled&&e.key==='-')zoom(5);else handled=false;if(handled){e.preventDefault();stopIdle();dirty=true}}
  bindCanvasEvents();
  // Navigation toolbar is opt-in. Legacy sections without this prop stay uncluttered.
  if(navigationPanelEnabled){
    const controls=document.createElement('div');
    controls.className='ims360-controls';
    controls.setAttribute('role','group');
    controls.setAttribute('aria-label','Painel de navegação do panorama');
    controls.innerHTML='<button type="button" data-action="zoom-in" aria-label="Aproximar">+</button><button type="button" data-action="zoom-out" aria-label="Afastar">−</button><button type="button" data-action="fullscreen" aria-label="Tela cheia">⛶</button>';
    view.appendChild(controls);
    controls.querySelector('[data-action="zoom-in"]').addEventListener('click',()=>zoom(-7));
    controls.querySelector('[data-action="zoom-out"]').addEventListener('click',()=>zoom(7));
    controls.querySelector('[data-action="fullscreen"]').addEventListener('click',()=>{if(document.fullscreenElement)document.exitFullscreen?.();else stage.requestFullscreen?.()});
  }
  const toggle=root.querySelector('.ims360-scene-toggle'),menu=root.querySelector('.ims360-scene-list');
  if(toggle&&menu){const enabled=root.dataset.scenesMenu==='true';toggle.hidden=!enabled;menu.hidden=true;if(enabled){const id='ims360-scene-menu-'+Math.random().toString(36).slice(2);menu.id=id;toggle.setAttribute('aria-controls',id);toggle.addEventListener('click',()=>{menu.hidden=!menu.hidden;toggle.setAttribute('aria-expanded',String(!menu.hidden))});for(const id of order){const btn=document.createElement('button');btn.type='button';btn.textContent=scenes[id].title||id;btn.addEventListener('click',()=>{loadScene(id);menu.hidden=true;toggle.setAttribute('aria-expanded','false')});menu.append(btn)}}}
  const oldNav=root.querySelector('.ims360-navigation');if(oldNav)oldNav.hidden=true;
  if('ResizeObserver' in window){resizeObserver=new ResizeObserver(()=>{resize();dirty=true});resizeObserver.observe(stage);resizeObserver.observe(view);}
  on(window,'resize',()=>{resize();dirty=true});
  if('IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>{visible=!!entries[0]?.isIntersecting;if(visible)dirty=true},{threshold:.01});observer.observe(stage);disposers.push(()=>observer.disconnect())}
  const removal=new MutationObserver(()=>{if(!root.isConnected){disposed=true;cancelAnimationFrame(frame);resizeObserver?.disconnect();for(const f of disposers)f();engine.destroy();removal.disconnect();instances.delete(root)}});removal.observe(document.documentElement,{childList:true,subtree:true});
  instances.set(root,{getView:()=>({yaw,pitch,hfov}),loadScene,gl:engine.gl});
  loadScene(sceneId);resize();frame=requestAnimationFrame(tick);
 }
 function scan(){document.querySelectorAll(`[data-plugin="${ID}"] .ims360`).forEach(initialize)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',scan,{once:true});else scan();
 new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});
})();

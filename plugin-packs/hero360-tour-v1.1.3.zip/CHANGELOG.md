# Hero360Tour 1.1.3 — Fix de captura e renderização

- Corrigido: `Capturar visão` armazena yaw, pitch e HFOV sem ser sobrescrito pelo posterior botão `Salvar cena`.
- Valores de entrada digitados manualmente são preservados da mesma forma.
- `ImobifyPluginEditor.save()` mantém o JSON atualizado ao retornar ao Studio.
- O renderer público utiliza o HFOV específico da cena em vez de impor o valor global a cada entrada.
- Se o WebGL falhar durante a inicialização ou upload da textura, substitui o canvas e ativa renderização Canvas 2D.
- Panoramas HTTP(S) solicitam CORS para habilitar textura WebGL/Canvas, preservando a imagem estática em caso de bloqueio externo.
- Cena sem panorama apresenta estado vazio identificável.

**Limitações:** imagens remotas exigem CORS para o modo interativo; prévia geral não foi validada com arquivos privados do usuário. Projeto de teste com duas condições WebGL e serialização do modal passou no Chromium local.

## Hero360Tour 1.1.2 — Painel de navegação opcional

No inspetor do Imobify Studio, o campo **Habilitar painel de navegação** inicia desligado. Ao ativar, mostra os botões +, − e tela cheia na cena. A roda do mouse permanece dedicada à rolagem da LP. A edição de panoramas no Tour360 Studio continua com seus próprios controles.

## Atualização 1.1.1 — navegação e rolagem
Roda do mouse passa pela cena para rolar a página; arraste vertical da câmera limitado a 100 px; toque vertical preserva scroll nativo; zoom permanece disponível nos botões e teclado.

# Hero360Tour

## 1.1.0 · 2026-10-17
- Novo renderizador esférico WebGL independente com alternativa Canvas 2D.
- Cobertura de toda a seção e largura da viewport sem corte aos 1180px.
- Hotspots de informação reescrevem Eyebrow, Headline e descrição.
- Hotspots de navegação mudam diretamente de cena.
- Panoramas com resolução superior à capacidade GPU são reduzidos para textura 2:1 segura.

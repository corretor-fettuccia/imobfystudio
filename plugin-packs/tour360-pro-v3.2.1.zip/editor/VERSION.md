# Tour 360 Editor — v3.2.1

## Alterações principais

- Branding consolidado em uma única peça compacta no player exportado: **texto + imagem/logotipo opcional + link configurável**.
- Posição do branding configurável: superior esquerdo, superior direito, inferior esquerdo ou inferior direito.
- Motor de **zona segura** no player exportado: menu de pontos e branding verificam colisões com controles Pannellum e bússola e se reposicionam automaticamente.
- O painel de pontos acompanha o botão do menu e evita colisão com branding.
- Opção **Mostrar bússola** preservada no projeto e aplicada ao player exportado.
- Navegação touch/mobile tratada como padrão do motor; o viewer preserva arraste por toque e pinch-to-zoom do Pannellum.
- Layout responsivo revisado para celular e tablet, incluindo mudanças de orientação.
- Estrutura interna elevada para v7.

## Não regressão

Mantidos nome do projeto, exportação modular sem Base64, pasta 360/, JavaScript externo com cabeçalho de propriedade, hotspots, edição por caneta e navegação automática estabilizados nas versões anteriores.


## Integração Imobify 5.12.4

- Adicionado contrato `window.ImobifyPluginEditor` para carregar e salvar o projeto dentro do modal do Plugin Play.
- Nenhuma alteração regressiva no comportamento visual do motor 3.2.0.

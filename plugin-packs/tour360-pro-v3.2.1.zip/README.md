# Tour 360 Pro 3.2.1 — Imobify Studio 5.12.4

# Tour 360 Pro 3.2.0

Plugin section para Imobify Studio 5.12.4.

- configuração completa no modal Tour 360 Studio;
- cenas e hotspots armazenados em `props.tourConfig`;
- publicação responsiva com toque/pinça;
- branding e menu de pontos com zona segura;
- imagens locais do JSON interno são extraídas pelo compilador do Studio.


## Integração 3.2.1
O editor avançado faz parte do próprio pacote Plugin Play. Ao instalar o ZIP no Imobify Studio 5.12.4, a section expõe o editor em modal sem depender de uma pasta externa copiada manualmente.
